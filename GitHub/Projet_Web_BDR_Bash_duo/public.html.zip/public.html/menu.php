<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Menu du Restaurant</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<header>
<a href="choix_accueil.php"><button class="btn btn-outline-dark me-5" type="submit">Accueil</button></a>
        <a href="logout.php"><button class="btn btn-outline-dark me-5" type="submit">Déconnexion</button></a>
        </header>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#">Le Restaurant Alfreddo</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <h2>Entrées</h2>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Salade César
                        <span class="badge badge-primary badge-pill">10€</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Asssiete de Fromages
                        <span class="badge badge-primary badge-pill">8€</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Soupe du Chef
                        <span class="badge badge-primary badge-pill">7€</span>
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <h2>Plats principaux</h2>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Pizza Margherita
                        <span class="badge badge-primary badge-pill">25€</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                    Lasagne Italienne
                        <span class="badge badge-primary badge-pill">20€</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Hamburger 
                        <span class="badge badge-primary badge-pill">22€</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <h2>Desserts</h2>
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Tiramissu
                        <span class="badge badge-primary badge-pill">8€</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Pastel de Natas
                        <span class="badge badge-primary badge-pill">7€</span>
                    </li>


                </ul>
            </div>

            

</body>
</html>
