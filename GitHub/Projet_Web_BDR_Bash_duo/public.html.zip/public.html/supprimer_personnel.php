<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$connexion = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// vérifier si l'ID du personnel a été envoyé via POST
if (isset($_POST['id_personnel_s'])) {
    $id_personnel = $_POST['id_personnel_s'];

    // supprimer le personnel correspondant de la table des personnels
    $sql = "DELETE FROM personnel WHERE id_p = $id_personnel";

    if (mysqli_query($conn, $sql)) {
        echo "Le personnel a été supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression du personnel: " . mysqli_error($conn);
    }
}

// fermer la connexion à la base de données
mysqli_close($conn);
// Redirection vers la page directeur
header('Location: directeur.php');