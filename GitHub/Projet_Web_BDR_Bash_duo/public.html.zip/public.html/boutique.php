<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Informations sur le manège</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        h1 {
            margin-top: 40px;
            margin-bottom: 20px;
            font-size: 36px;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 10px;
            line-height: 1.5;
        }

        b {
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
    </style>

<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction</title> <!-- Changer le nom du site-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="./assets/imgs/icon.png" />
    


</head>

<body>
    <header>
        <h1>Informations sur la boutique</h1>
        <a href="choix_accueil.php"><button class="btn btn-outline-light me-5" type="submit">Accueil</button></a>
        <a href="logout.php"><button class="btn btn-outline-light me-5" type="submit">Déconnexion</button></a>
    </header>

    <div class="container">
        <?php
        include 'myparam.inc.php';
        // Connexion à la base de données MySQL
        $connexion = mysqli_connect(HOST, USER, PASS, DB);
        // Vérification de la connexion
        if ($connexion->connect_error) {
            die("La connexion a échoué: " . $connexion->connect_error);
        }

        // Récupération des informations de la boutique
        $id_boutique = $_GET['id_b'];
        $requete = $connexion->prepare("SELECT * FROM boutique WHERE id_b = ?");
        $requete->bind_param("i", $id_boutique);
        $requete->execute();
        $resultat = $requete->get_result()->fetch_assoc();

        // Affichage des informations de la boutique
        echo '<h1>' . $resultat['nom_b'] . '</h1>';
        echo '<img src="boutique/' . $resultat['nom_b'] . '.jpg" alt="image de ' . $resultat['nom_b'] . '"><br>';
        echo '<p><b>Nom de l\'emplacement : </b>' . $resultat['nom_emplacement'] . '</p>';

        // Requête SQL pour récupérer les noms d'objets vendus par la boutique
        $sql = "SELECT distinct type_objet FROM vente WHERE vente.id_b = $id_boutique";

        // Exécution de la requête SQL
        $resultat1 = mysqli_query($connexion, $sql);

        // Vérification du résultat de la requête
        if (mysqli_num_rows($resultat1) > 0) {
            // Affichage des noms d'objets vendus par la boutique
            echo '<b>Objet vendu dans le magasin : </b>';
            while ($row = mysqli_fetch_assoc($resultat1)) {
                echo $row["type_objet"] . ", ";
            }
        } else {
            echo "Aucun objet vendu par cette boutique.";
        }

        // Requête SQL pour récupérer le nombre de tables dans le restaurant
        $requete2 = $connexion->prepare("SELECT * FROM restaurant");
        $requete2->execute();
        $resultat2 = $requete2->get_result()->fetch_assoc();





            //savoir si la boutique est un restaurant ou non
        if($id_boutique ==  $resultat2['id_b']){

            //ajouter un bouton pour aller dans le menu du resto
            
            
            echo '<p><b>Nombre de tables : </b>' . $resultat2['nombre_table'] . '</p>';
            echo '<a href="menu.php"> <button class="btn btn-outline-dark me-5" type="submit">Menu</button></a>';
            
        }

        // Fermeture de la connexion à la base de données
        $connexion->close();
        ?>
    </div>

</body>

</html>