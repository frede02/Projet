

<?php
include 'myparam.inc.php';

session_start();
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());
}




// Vérifie si le formulaire de connexion a été soumis
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];



    $sql = "SELECT * FROM personnel WHERE nom_p='$username'";
    $result = $conn->query($sql);




    
    
 

    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            // Save the user's ID in a session variable
            
            $_SESSION['user_id'] = $row['id_p'];
            $password_hash = $row['mdp_p'];
        }


        //verification du mot de passe
        if (password_verify($password, $password_hash)) {




        


        // Redirection vers la page d'accueil du personnel connecté
        $id = $_SESSION['user_id'];
        $tables = ['directeur', 'vendeur', 'cm', 'serveur', 'technicien'];
        foreach ($tables as $table) {
            $sql = "SELECT * FROM $table WHERE id_p='$id'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {

                $_SESSION['metier'] = $table;

                    if($table == 'technicien'){

                $sql1 = "SELECT nom_z from atelier where id_atelier in (SELECT  id_atelier from repare where id_p = $_SESSION[user_id])" ;

                $result1 = $conn->query($sql1);
                if ($result1->num_rows > 0) {
                    // output data of each row
                    while($row = $result1->fetch_assoc()) {
                    
                        $_SESSION['zone'] = $row['nom_z'];
                        echo $_SESSION['zone'];
                    }
                }
            }
    



                header("Location: accueil_$table.php");
                exit();
            }
        }

    }

    } else {
        header("Location: index.php");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction</title> <!-- Changer le nom du site-->
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="./assets/imgs/icon.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <!-- POST - username | password | submit -->
    <header class='mb-5'>
        <nav class="navbar navbar-dark bg-dark navbar-expand-md">
            <div class="container-fluid">
                <div class="navbar-brand">
                    <h1>Pira'traction</h1>
                </div>
            </div>
        </nav>
    </header>

    <main class='container'>
        <div class="card p-4">
            <h2 class=''>Connexion</h2>

            <form action="" method="POST">
                    <div>
                        <label class='form-label' for="nom">Nom de Famille</label>
                        <input class='form-control' type="text" name="username" value="" placeholder="Votre nom de famille">
                    </div>
                    <div>
                        <label class='form-label' for="password">Mot de passe</label>
                        <input class='form-control' type="password" name="password" value="" placeholder="Votre mot de passe">
                    </div>
                    <div class='mt-3'>
                        <input class='btn form-control btn-warning' type="submit" name="submit" value="Connexion">
                    </div>
                </form>

               
        </div>
    </main>

    <footer class='bg-dark fixed-bottom p-4'>
        <span class='text-light'>
            Projet réalisé par Halim et Frederic
        </span>
    </footer>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>

