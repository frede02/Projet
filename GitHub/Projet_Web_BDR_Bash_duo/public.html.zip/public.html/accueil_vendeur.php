<?php
include 'myparam.inc.php';

session_start();

// Récupéré l'id du personnel connecté est stocké dans une variable
$id_p = $_SESSION['user_id'];

// Connexion à la base de données MySQL
$connexion = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$connexion) {
    die("La connexion a échoué : " . mysqli_connect_error());
}









// Récupéré le nom et le prenom du personnel connecté est stocké dans une variable

$sql = "SELECT nom_p, prenom_p FROM personnel Where id_p = $id_p";
$result = mysqli_query($connexion, $sql);
$row = mysqli_fetch_assoc($result);
$nom_p = $row['nom_p'];
$prenom_p = $row['prenom_p'];










?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction</title> <!-- Changer le nom du site-->
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="./assets/imgs/icon.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

    <style>

        .slider {
            width: 65%;
            margin: 2% auto;
        }

        .slider img {
            display: block;
            max-width: 97%;
            height: auto;
            margin: 0 auto;
        }

        .slick-prev,
        .slick-next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0;
            line-height: 0;
            border: none;
            background: none;
            color: #fff;
            z-index: 1;
        }

        .slick-prev:before,
        .slick-next:before {
            font-family: 'slick';
            font-size: 40px;
            line-height: 1;
            opacity: .75;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, .3);
        }

        .slick-prev {
            left: 20px;
        }

        [dir='rtl'] .slick-prev {
            right: 20px;
            left: auto;
        }

        .slick-prev:before {
            content: '←';
        }

        .slick-next {
            right: 20px;
        }

        [dir='rtl'] .slick-next {
            right: auto;
            left: 20px;
        }

        .slick-next:before {
            content: '→';
        }

        .slick-dots {
            display: flex !important;
            justify-content: center;
            margin: 20px 0;
            padding: 0;
            list-style: none;
        }

        .slick-dots li {
            margin: 0 10px;
        }

        .slick-dots button {
            font-size: 0;
            line-height: 0;
            display: block;
            width: 10px;
            height: 10px;
            padding: 5px;
            border-radius: 50%;
            border: none;
            background-color: #bbb;
            cursor: pointer;
            opacity: .75;
            transition: all .3s ease;
        }

        .slick-dots button:hover,
        .slick-dots button:focus {
            outline: none;
            opacity: 1;
        }

        .slick-dots button:hover:before,
        .slick-dots button:focus:before {
            transform: scale(1.3);
        }

        .slick-dots .slick-active button {
            background-color: #fff;
        }

        .slick-dots .slick-active button:before {
            opacity: 1;
            transform: scale(1.3);
        }
    </style>


</head>
<body>
    <!-- POST - username | password | submit -->
    <header class='mb-5'>
        <nav class="navbar navbar-dark bg-dark navbar-expand-md">
            <div class="container-fluid">
                <div class="navbar-brand">
                    <h1>Pira'traction</h1>
                </div>
            </div>
            <a href="logout.php"><button class="btn btn-outline-light me-5" type="submit">Déconnexion</button></a>
        </nav>
    </header>

    <main class='container'>
        <div class="card p-4">
            <h2 class='fs-1'>Accueil</h2>


            <div class="card-body">
                <p class='fs-3'>Bonjour <?php echo $prenom_p . " " . $nom_p ?>, Bienvenue Vendeur</p>
                <p class='fs-3'>Vous pouvez accéder aux différentes pages du site en cliquant sur les boutons ci-dessous.</p>



                
                <div class="d-flex justify-content-center">
                    <div class="fs-1">
                        
                        <a href="stock.php" class="btn btn-primary fs-3 me-5"  >Stock</a>
                        <a href="recherche.html" class="btn btn-primary fs-3 me-5">Rechercher</a>
                        <a href="compte.php" class="btn btn-primary fs-3 me-5">Gestion du compte</a>

                    </div>

        </div>
    </main>

    <div class="slider">
        <div>
            <img src="manege/Le Briseur de Nuque.jpg">
            <h3>Le Briseur de Nuque</h3>
        </div>
        <div>
            <img src="manege/Le Double 8.jpg">
            <h3>Le Double 8</h3>
        </div>
        <div>
            <img src="manege/Petit Tonnerre.jpg">
            <h3>Petit Tonnerre</h3>
        </div>
        <div>
            <img src="manege/Mega Splash.jpg">
            <h3>Mega Splash</h3>
        </div>
        <div>
            <img src="manege/Rencontre des chèvres.jpg">
            <h3>Rencontre des Chèvres</h3>
        </div>
    </div>
    <script>
        $('.slider').slick({
            centerMode: true,
            centerPadding: '60px',
            slidesToShow: 3,
            responsive: [
                {
                    breakpoint: 768,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow: 3
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        arrows: false,
                        centerMode: true,
                        centerPadding: '40px',
                        slidesToShow
                            : 1
                    }
                }
            ]
        });
    </script>
    <footer class='bg-dark fixed-bottom p-4'>
        <span class='text-light'>
            Projet réalisé par Halim et Frederic
        </span>
    </footer>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>

