<?php
include 'myparam.inc.php';


// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());

}
session_start();
$table =  $_SESSION['metier'];
header("Location: accueil_$table.php");




?>