<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// vérifier si l'ID de boutique a été envoyé via POST
if (isset($_POST['id_boutique_s'])) {
    $id_boutique = $_POST['id_boutique_s'];

    // supprimer la boutique correspondant de la table des boutiques
    $sql = "DELETE FROM boutique WHERE id_b = $id_boutique";

    if (mysqli_query($conn, $sql)) {
        echo "La boutique a été supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression de la boutique: " . mysqli_error($conn);
    }
}

// fermer la connexion à la base de données
mysqli_close($conn);
// Redirection vers la page directeur
header('Location: directeur.php');