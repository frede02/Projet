<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérifier si la connexion a réussi
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

// Récupération des données du formulaire
$nom_zone = $_POST['nom_zone_a'];
$id_a = $_POST['id_a'];

// Construction de la requête SQL pour ajouter l'atelier
$sql = "INSERT INTO atelier (id_atelier, nom_zone) VALUES ('$id_a', '$nom_zone')";

// Exécution de la requête SQL
if ($conn->query($sql) === TRUE) {
    echo "L'atelier a été ajouté avec succès.";
} else {
    echo "Une erreur est survenue lors de l'ajout de l'atelier : " . $conn->error;
}
$conn->close();
// Redirection vers la page directeur
header('Location: directeur.html');
