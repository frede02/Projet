<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérifier si la connexion a réussi
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

// Récupération des données du formulaire
$nom_b = $_POST['nom_boutique'];
$nom_emplacement = $_POST['emplacement'];
$id_b = $_POST['id_boutique'];

// Construction de la requête SQL pour ajouter la boutique
$sql = "INSERT INTO boutique (id_b, nom_b, nom_emplacement) VALUES ('$id_b', '$nom_b', '$nom_emplacement')";

// Exécution de la requête SQL
if ($conn->query($sql) === TRUE) {
    echo "La boutique a été ajouté avec succès.";
} else {
    echo "Une erreur est survenue lors de l'ajout de la boutique : " . $conn->error;
}
$conn->close();
// Redirection vers la page directeur
header('Location: directeur.php');
