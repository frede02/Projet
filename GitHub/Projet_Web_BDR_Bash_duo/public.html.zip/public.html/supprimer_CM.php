<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// vérifier si l'ID du manège a été envoyé via POST
if (isset($_POST['id_manege_s'])) {
    $id_manege = $_POST['id_manege_s'];

    // supprimer le manège correspondant de la table des manèges
    $sql = "DELETE FROM manege WHERE id_m = $id_manege";

    if (mysqli_query($conn, $sql)) {
        echo "Le manège a été supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression du manège: " . mysqli_error($conn);
    }
}

// fermer la connexion à la base de données
mysqli_close($conn);
// Redirection vers la page directeur
header('Location: directeur.php');