
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Informations sur le manège</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        h1 {
            margin-top: 40px;
            margin-bottom: 20px;
            font-size: 36px;
        }

        img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 10px;
            line-height: 1.5;
        }

        b {
            font-weight: bold;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
    </style>

 <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction</title> <!-- Changer le nom du site-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="icon" href="./assets/imgs/icon.png" />
    






</head>

<body>
    <header>
        <h1>Informations sur le manège</h1>

        <a href="choix_accueil.php"><button class="btn btn-outline-light me-5" type="submit">Accueil</button></a>
        <a href="logout.php"><button class="btn btn-outline-light me-5" type="submit">Déconnexion</button></a>
    </header>

    <div class="container">
        <?php
        

        
include 'myparam.inc.php';


// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());
}


    session_start();

        // Récupération des informations du manège
        $id_manege = $_GET['id_m'];
        $requete = $conn->prepare("SELECT * FROM manege WHERE id_m = ?");
        $requete->bind_param("i", $id_manege);
        $requete->execute();
        $resultat = $requete->get_result()->fetch_assoc();

        // Affichage des informations du manège
        echo '<h1>' . $resultat['nom_m'] . '</h1>';
        echo '<img src="manege/' . $resultat['nom_m'] . '.jpg" alt="image de ' . $resultat['nom_m'] . '"><br>';
        echo '<p><b>Description : </b>' . $resultat['description_m'] . '</p>';
        echo '<p><b>Taille minimale : </b>' . $resultat['taille_min_m'] . ' cm</p>';
        echo '<p><b>Nom de la famille : </b>' . $resultat['nom_famille'] . '</p>';
        if ($resultat['fonctionne_m'] == 1) {
            echo '<p><b>Fonctionement : </b> Fonctionne </p>';
        }
        if ($resultat['fonctionne_m'] == 0) {
            echo '<p><b>Fonctionement : </b> Ne fonctionne pas </p>';
        }
        echo '<p><b>Id du CM : </b>' . $resultat['id_p'] . '</p>';
        echo '<p><b>Nom de la zone : </b>' . $resultat['nom_z'] . '</p>';


        
        // Affichage du bouton pour modifier le manège
        if ($_SESSION['user_id'] == $resultat['id_p']) {

             $_SESSION['id_manege'] = $resultat['id_m']; 
        ?>
            <form method="POST" action="CM.php">
                <input type="submit" value="modifier">
            </form>
        <?php
        }

        // Affichage du bouton pour activer le manège

        
        if($_SESSION['metier'] == 'technicien'){
      if   ($_SESSION['zone'] == $resultat['nom_z'] && $resultat['fonctionne_m'] == 0) {
        ?>
            <form method="POST" action="tech.php">
                <input type="submit" value="activer le manège">
               <?php  $_SESSION['id_manege'] = $resultat['id_m']; ?>
            </form>
        <?php
        }}
        $conn->close();
        ?>
    </div>

</body>

</html>