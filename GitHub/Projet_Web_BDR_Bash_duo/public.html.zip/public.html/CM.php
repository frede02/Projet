
<?php

session_start();


$manege = $_SESSION['id_manege'];

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Gestion des manèges</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F5F5F5;
        }

        h1 {
            color: #FF5733;
            font-size: 36px;
            margin-top: 20px;
        }

        h2 {
            color: #5D6D7E;
            font-size: 24px;
            margin-top: 30px;
        }

        form {
            margin-top: 20px;
            border: 2px solid #5D6D7E;
            padding: 20px;
            border-radius: 5px;
            background-color: #FFFFFF;
        }

        label {
            display: inline-block;
            width: 200px;
            text-align: right;
            margin: 10px;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 300px;
            border-radius: 5px;
            border: 1px solid #CCCCCC;
            padding: 10px;
            margin: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #FF5733;
            color: #FFFFFF;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        input[type="submit"]:hover {
            background-color: #E74C3C;
        }

        select {
            width: 320px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin: 5px;
        }
    </style>
</head>

<body>
    <h1>Gestion des manèges</h1>
    <h2>Ajouter un manège :</h2>
    <form method="POST" action="ajouter_CM.php">
        <label for="id_man">Id du manège :</label>
        <input type="number" name="id_man" id="id_man" required><br>
        <label for="nom_man">Nom du manège :</label>
        <input type="text" name="nom_man" id="nom_man" required><br>
        <label for="description_man">Description :</label>
        <input type="text" name="description_man" id="description_man"><br>
        <label for="taille_min">Taille minimale requise :</label>
        <input type="number" name="taille_min" id="taille_min"><br>
        <label for="fonctionne">Fonctionnement :</label>
        <select name="fonctionne" id="fonctionne" required>
            <option value="true">Fonctionne</option>
            <option value="false">Hors service</option>
        </select><br>
        <label for="famille">Famille :</label>
        <input type="number" name="famille" id="famille" required><br>
        <label for="id_perso">ID du personnel responsable :</label>
        <input type="number" name="id_p"><br>
        <label for="zone">Zone :</label>
        <input type="text" name="zone" required><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Supprimer un manege :</h2>
    <form action="supprimer_CM.php" method="POST">
        <label for="id_manege_s">ID du manège à supprimer:</label>
        <input type="number" name="id_manege_s" id="id_manege_s" required>
        <input type="submit" value="Supprimer">
    </form>
    <h2>Modifier un manège</h2>
    <form method="post" action="modifier_CM.php">
        <label for="id_manege">ID du manège à modifier :</label>
        <input type="number"  name="id_manege"  value='<?php echo $manege; ?>'><br>
        <label for="nom_manege">Nom du manège :</label>
        <input type="text" name="nom_manege"><br>
        <label for="description_manege">Description du manège :</label>
        <input type="text" name="description_manege"><br>
        <label for="taille_min_manege">Taille minimale requise :</label>
        <input type="number" name="taille_min_manege"><br>
        <label for="fonctionne_manege">Fonctionnement :</label>
        <select name="fonctionne_manege" id="fonctionne_manege">
            <option value="2">Ne rien faire</option>
            <option value="0">Hors service</option>
        </select><br>
        <label for="nom_famille">Nom de la famille du manège :</label>
        <input type="text" name="nom_famille"><br>
        <label for="nom_zone">Nom de la zone du manège :</label>
        <input type="text" name="nom_zone"><br>
        <input type="submit" value="Modifier">
    </form>

</body>

</html>