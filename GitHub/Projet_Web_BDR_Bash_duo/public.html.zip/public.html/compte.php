<?php
session_start();

include 'myparam.inc.php';


// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());
}

// Vérifie si le formulaire de mise à jour a été soumis
if (isset($_POST['update'])) {
    $id = $_SESSION['user_id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $password = $_POST['password'];

    // Hashage du mot de passe
    $hash_password = password_hash($password, PASSWORD_DEFAULT);



    

    // Mettre à jour les informations dans la base de données
    $sql = "UPDATE personnel SET nom_p='$nom', prenom_p='$prenom', mdp_p='$hash_password' WHERE id_p='$id'";
    if ($conn->query($sql) === TRUE) {
                  // Redirection vers la page d'accueil du personnel connecté
        $id = $_SESSION['user_id'];
        $tables = ['directeur', 'vendeur', 'cm', 'serveur'];
        foreach ($tables as $table) {
            $sql = "SELECT * FROM $table WHERE id_p='$id'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {

                header("Location: accueil_$table.php");
                exit();
            }
        }
}}

// Récupérer les informations de l'utilisateur à partir de la base de données
$id = $_SESSION['user_id'];
$sql = "SELECT * FROM personnel WHERE id_p='$id'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$nom = $row['nom_p'];
$prenom = $row['prenom_p'];
$password = $row['mdp_p'];


?>











<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction - Profil</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZintegrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZ1NyOJ//lfB+RoA+kKj3g/fqiuYw94vOZfhjBZ1X9wwA0nl6LsU6cg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

  </head>
<body>

<header class='mb-5'>
        <nav class="navbar navbar-dark bg-dark navbar-expand-md">
            <div class="container-fluid">
                <div class="navbar-brand">
                    <h1>Pira'traction</h1>
                    </div>
                    <a href="choix_accueil.php"><button class="btn btn-outline-light me-5" type="submit">Accueil</button></a>
        <a href="logout.php"><button class="btn btn-outline-light me-5" type="submit">Déconnexion</button></a>
               
            </div>
        </nav>
    </header>



  <body>
        <h2 class="text-dark text-center mb-5">Gestion du Compte</h2>
        <form class="d-flex justify-content-center" method="POST" action="compte.php">
            <div class="mb-3 me-2">
                <label for="nom" class="form-label">Nom :</label>
                <input type="text" class="form-control" id="nom" name="nom" value="<?php echo $nom; ?>">
            </div>
            <div class="mb-3 me-2 ">
                <label for="prenom" class="form-label">Prénom :</label>
                <input type="text" class="form-control" id="prenom" name="prenom" value="<?php echo $prenom; ?>">
            </div>
            <div class="mb-3 me-2">
                <label for="password" class="form-label">Mot de passe :</label>
                <input type="password" class="form-control" id="password" name="password" value="">
            </div>
            <div class="mb-3 mt-4">
                <input type="submit" class="btn btn-primary " name="update" value="Mettre à jour">
            </div>
        </form>
   </body>

    <footer class='bg-dark fixed-bottom p-4'>
        <span class='text-light'>
            Projet réalisé par Halim et Frederic
        </span>
    </footer>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.3/js/bootstrap.min.js" integrity="sha512-1/RvZTcCDEUjY/CypiMz+iqqtaoQfAITmNSJY17Myp4Ms5mdxPS5UV7iOfdZoxcGhzFbOm6sntTKJppjvuhg4g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html> 