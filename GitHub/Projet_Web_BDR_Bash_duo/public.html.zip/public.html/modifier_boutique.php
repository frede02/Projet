<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérification si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $id_boutique = $_POST["id_boutique_m"];
    $nouveau_nom_boutique = $_POST["nom_boutique_m"];
    $nouveau_emplacement_boutique = $_POST["emplacement_m"];

    // Requête SQL pour mettre à jour les données du manège
    $sql = "UPDATE boutique SET ";
    if (!empty($nouveau_nom_boutique)) {
        $sql .= "nom_b = '" . $nouveau_nom_boutique . "', ";
    }
    if (!empty($nouveau_emplacement_boutique)) {
        $sql .= "nom_emplacement = '" . $nouveau_emplacement_boutique . "', ";
    }
    $sql = rtrim($sql, ", "); // Supprimer la dernière virgule
    $sql .= " WHERE id_b = " . $id_boutique;

    if (mysqli_query($conn, $sql)) {
        echo "Mise à jour effectuée avec succès.";
    } else {
        echo "Erreur: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Fermeture de la connexion à la base de données
mysqli_close($conn);

header('Location: directeur.php');
