<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Résultats de la recherche</title>

    <link rel="icon" href="./assets/imgs/icon.png" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333333;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }

        h1 {
            font-size: 2.5rem;
            margin: 0;
        }

        a {
            color: #333333;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 800px;
            margin: auto;
            background-color: #ffffff;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
        }

        .result {
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.2s ease;
        }

        .result:hover {
            background-color: #f2f2f2;
        }

        .result a {
            font-size: 1.5rem;
        }

        .result p {
            margin: 0;
            font-size: 1.2rem;
            color: #666666;
        }

        .result .image {
            width: 100px;
            height: 100px;
            margin-right: 10px;
            border-radius: 5px;
            overflow: hidden;
            float: left;
        }

        .result .image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    </style>
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piratraction</title> <!-- Changer le nom du site-->
    
   


</head>

<body>
    <header>
        <h1>Stock d'objet</h1>
        <a href="choix_accueil.php"><button class="btn btn-outline-light me-5" type="submit">Accueil</button></a>
        <a href="logout.php"><button class="btn btn-outline-light me-5" type="submit">Déconnexion</button></a>
        
    </header>
    <div class="container">
        <?php
        session_start();

        include 'myparam.inc.php';
        // Connexion à la base de données MySQL
        $connexion = mysqli_connect(HOST, USER, PASS, DB);

        // Vérification des erreurs de connexion
        if ($connexion->connect_error) {
            die("Connection failed: " . $connexion->connect_error);
        }

        // Requête SQL pour la recherche
        $requete = $connexion->prepare("SELECT * FROM objet");

        // Exécution de la requête
        $requete->execute();

        // Récupération des résultats
        $resultats = $requete->get_result();

        // Affichage des résultats sous forme de liens cliquables
        while ($resultat = $resultats->fetch_assoc()) {
            echo '<div class="result">';
            echo $resultat['type_objet'] . " : " . $resultat['quantiter_obj'];
            echo '</div>';
        }
        // Fermeture de la connexion à la base de données
        $connexion->close();
        ?>

    </div>