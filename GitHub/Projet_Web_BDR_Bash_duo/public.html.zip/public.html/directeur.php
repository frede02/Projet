
<?php

include 'myparam.inc.php';


// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);

// Vérification de la connexion
if (!$conn) {
    die("La connexion a échoué : " . mysqli_connect_error());

}
session_start();


if("directeur" !=  $_SESSION['metier']){

header("Location: logout.php");

}




?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Gestion du parc d'attractions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #F5F5F5;
        }

        h1 {
            color: #FF5733;
            font-size: 36px;
            margin-top: 20px;
        }

        h2 {
            color: #5D6D7E;
            font-size: 24px;
            margin-top: 30px;
        }

        form {
            margin-top: 20px;
            border: 2px solid #5D6D7E;
            padding: 20px;
            border-radius: 5px;
            background-color: #FFFFFF;
        }

        label {
            display: inline-block;
            width: 200px;
            text-align: right;
            margin: 10px;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        select {
            width: 300px;
            border-radius: 5px;
            border: 1px solid #CCCCCC;
            padding: 10px;
            margin: 10px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #FF5733;
            color: #FFFFFF;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
        }

        input[type="submit"]:hover {
            background-color: #E74C3C;
        }

        select {
            width: 320px;
        }

        .error {
            color: red;
            font-size: 14px;
            margin: 5px;
        }
    </style>

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Piratraction</title> <!-- Changer le nom du site-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css" integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="icon" href="./assets/imgs/icon.png" />
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">


</head>
</head>

<header>
    <h1>Gestion du parc d'attractions</h1>
<a href="choix_accueil.php"><button class="btn btn-outline-dark me-5" type="submit">Accueil</button></a>
<a href="logout.php"><button class="btn btn-outline-dark me-5" type="submit">Déconnexion</button></a>
</header>

<body>
   
    <h2>Ajouter un manège :</h2>
    <form method="POST" action="ajouter_man.php">
        <label for="id_man">Id du manège :</label>
        <input type="number" name="id_man" id="id_man" required><br>
        <label for="nom_man">Nom du manège :</label>
        <input type="text" name="nom_man" id="nom_man" required><br>
        <label for="description_man">Description :</label>
        <input type="text" name="description_man" id="description_man"><br>
        <label for="taille_min">Taille minimale requise :</label>
        <input type="number" name="taille_min" id="taille_min"><br>
        <label for="fonctionne">Fonctionnement :</label>
        <select name="fonctionne" id="fonctionne" required>
            <option value="true">Fonctionne</option>
            <option value="false">Hors service</option>
        </select><br>
        <label for="famille">Famille :</label>
        <input type="text" name="famille" id="famille" required><br>
        <label for="id_perso">ID du personnel responsable :</label>
        <input type="number" name="id_p"><br>
        <label for="zone">Zone :</label>
        <input type="text" name="zone" required><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Ajouter une boutique :</h2>
    <form method="POST" action="ajouter_boutique.php">
        <label for="id_boutique">Id de la boutique :</label>
        <input type="number" name="id_boutique" id="id_boutique" required><br>
        <label for="nom_boutique">Nom de la boutique :</label>
        <input type="text" name="nom_boutique" id="nom_boutique" required><br>
        <label for="emplacement">Emplacement :</label>
        <input type="text" name="emplacement" id="emplacement" required><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Ajouter du personnel :</h2>
    <form method="POST" action="ajouter_personnel.php">
        <label for="id_personnel">Id du personnel :</label>
        <input type="number" name="id_personnel" id="id_personnel" required><br>
        <label for="nom_personnel">Nom :</label>
        <input type="text" name="nom_personnel" id="nom_personnel" required><br>
        <label for="prenom_personnel">Prénom :</label>
        <input type="text" name="prenom_personnel" id="prenom_personnel" required><br>
        <label for="date_naissance">Date de naissance :</label>
        <input type="date" name="date_naissance" id="date_naissance"><br>
        <label for="ss">Numéro de sécurité sociale :</label>
        <input type="text" name="ss" id="ss"><br>
        <label for="mdp">Mot de passe :</label>
        <input type="password" name="mdp" id="mdp" required><br>
        <label for="fonction">Fonction :</label>
        <select name="fonction" id="fonction" required>
            <option value="vendeur">Vendeur</option>
            <option value="CM">Responsable</option>
            <option value="technicien">Technicien</option>
            <option value="serveur">Serveur</option>
        </select><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Supprimer un manege :</h2>
    <form action="supprimer_manege.php" method="POST">
        <label for="id_manege_s">ID du manège à supprimer:</label>
        <input type="number" name="id_manege_s" id="id_manege_s" required>
        <input type="submit" value="Supprimer">
    </form>
    <h2>Supprimer une boutique :</h2>
    <form action="supprimer_boutique.php" method="POST">
        <label for="id_boutique_s">ID de la boutique à supprimer:</label>
        <input type="number" name="id_boutique_s" id="id_boutique_s" required>
        <input type="submit" value="Supprimer">
    </form>
    <h2>Supprimer un personnel :</h2>
    <form action="supprimer_personnel.php" method="POST">
        <label for="id_personnel_s">ID du personnel à supprimer:</label>
        <input type="number" name="id_personnel_s" id="id_personnel_s" required>
        <input type="submit" value="Supprimer">
    </form>
    <h2>Modifier un manège</h2>
    <form method="post" action="modifier_manege.php">
        <label for="id_manege">ID du manège à modifier :</label>
        <input type="number" name="id_manege" required><br>
        <label for="nom_manege">Nom du manège :</label>
        <input type="text" name="nom_manege"><br>
        <label for="description_manege">Description du manège :</label>
        <input type="text" name="description_manege"><br>
        <label for="taille_min_manege">Taille minimale requise :</label>
        <input type="number" name="taille_min_manege"><br>
        <label for="fonctionne_manege">Fonctionnement :</label>
        <select name="fonctionne_manege" id="fonctionne_manege" required>
            <option value="1">Fonctionne</option>
            <option value="0">Hors service</option>
        </select><br>
        <label for="nom_famille">Nom de la famille du manège :</label>
        <input type="text" name="nom_famille"><br>
        <label for="id_p">ID du personnel responsable :</label>
        <input type="number" name="id_p"><br>
        <label for="nom_zone">Nom de la zone du manège :</label>
        <input type="text" name="nom_zone"><br>
        <input type="submit" value="Modifier">
    </form>
    <h2>Modifier une boutique :</h2>
    <form method="POST" action="modifier_boutique.php">
        <label for="id_boutique_m">Id de la boutique à modifier :</label>
        <input type="number" name="id_boutique_m" id="id_boutique_m" required><br>
        <label for="nom_boutique_m">Nom de la boutique :</label>
        <input type="text" name="nom_boutique_m" id="nom_boutique_m"><br>
        <label for="emplacement_m">Emplacement :</label>
        <input type="text" name="emplacement_m" id="emplacement_m"><br>
        <input type="submit" value="Modifier">
    </form>
    <h2>Modifier le personnel :</h2>
    <form method="POST" action="modifier_personnel.php">
        <label for="id_personnel_m">Id du personnel a modifier :</label>
        <input type="number" name="id_personnel_m" id="id_personnel_m"><br>
        <label for="nom_personnel">Nom :</label>
        <input type="text" name="nom_personnel_m" id="nom_personnel_m"><br>
        <label for="prenom_personnel_m">Prénom :</label>
        <input type="text" name="prenom_personnel_m" id="prenom_personnel_m"><br>
        <label for="date_naissance_m">Date de naissance :</label>
        <input type="date" name="date_naissance_m" id="date_naissance_m"><br>
        <label for="ss_m">Numéro de sécurité sociale :</label>
        <input type="text" name="ss_m" id="ss_m"><br>
        <label for="mdp_m">Mot de passe :</label>
        <input type="password" name="mdp_m" id="mdp_m"><br>
        <label for="fonction">Fonction :</label>
        <select name="fonction_m" id="fonction_m" required>
            <option value="rien">Ne pas changer</option>
            <option value="vendeur">Vendeur</option>
            <option value="CM">Responsable</option>
            <option value="technicien">Technicien</option>
            <option value="serveur">Serveur</option>
        </select><br>
        <input type="submit" value="Modifier">
    </form>
    <h2>Ajouter un atelier :</h2>
    <form method="POST" action="ajouter_atelier.php">
        <label for="id_a">Id de l'atelier :</label>
        <input type="number" name="id_a" id="id_a" required><br>
        <label for="nom_zone_a">Nom de la zone :</label>
        <input type="text" name="nom_zone_a" id="nom_zone_a" required><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Supprimer un atelier :</h2>
    <form method="POST" action="supprimer_vendeur.php">
        <label for="id_a_s">Id de l'atelier a supprimer :</label>
        <input type="number" name="id_a_s" id="id_a_s"><br>
        <input type="submit" value="Supprimer">
    </form>
    <h2>Ajouter les vendeurs :</h2>
    <form method="POST" action="ajouter_vendeur.php">
        <label for="id_v">Id du vendeur :</label>
        <input type="number" name="id_v" id="id_v"><br>
        <label for="id_b">Id de la boutique:</label>
        <input type="text" name="id_b" id="id_b"><br>
        <input type="submit" value="Ajouter">
    </form>
    <h2>Supprimer les vendeurs :</h2>
    <form method="POST" action="supprimer_vendeur.php">
        <label for="id_v_s">Id du vendeur :</label>
        <input type="number" name="id_v_s" id="id_v_s"><br>
        <label for="id_b_s">Id de la boutique:</label>
        <input type="text" name="id_b_s" id="id_b_s"><br>
        <input type="submit" value="Supprimer">
    </form>
</body>

</html>