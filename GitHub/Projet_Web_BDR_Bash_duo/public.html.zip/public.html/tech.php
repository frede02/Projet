<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

    // Récupération des données du formulaire
    $id_manege = $_SESSION['id_manege'];

    // Requête SQL pour mettre à jour les données du manège
    $sql = "UPDATE manege SET fonctionne_m = 1  WHERE id_m = $id_manege";

    if (mysqli_query($conn, $sql)) {
        echo "Mise à jour effectuée avec succès.";
    } else {
        echo "Erreur: " . $sql . "<br>" . mysqli_error($conn);
    }


    header("Location: accueil_technicien.php");
                
// Fermeture de la connexion à la base de données
mysqli_close($conn);
