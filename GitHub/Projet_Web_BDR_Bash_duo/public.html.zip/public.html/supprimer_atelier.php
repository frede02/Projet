<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// vérifier si l'ID de l'atelier a été envoyé via POST
if (isset($_POST['id_a_s'])) {
    $id_a = $_POST['id_a_s'];

    // supprimer l'atelier correspondant de la table des ateliers
    $sql = "DELETE FROM atelier WHERE id_atelier = $id_a";

    if (mysqli_query($conn, $sql)) {
        echo "L'atelier a été supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression de l'atelier : " . mysqli_error($conn);
    }
}

// fermer la connexion à la base de données
mysqli_close($conn);

// Redirection vers la page directeur
header('Location: directeur.php');