<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérification si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $id_personnel = $_POST["id_personnel_m"];
    $nouveau_nom_personnel = $_POST["nom_personnel_m"];
    $nouveau_prenom_personnel = $_POST["prenom_personnel_m"];
    $nouvelle_date_naissance_manege = $_POST["date_naissance_m"];
    $nouveau_ss_personnel = $_POST["ss_m"];
    $nouveau_mdp_personnel = $_POST["mdp_m"];
    $nouvelle_fonction_personnel = $_POST["fonction_m"];

    // Requête SQL pour mettre à jour les données du manège
    $sql = "UPDATE personnel SET ";
    if (!empty($nouveau_nom_personnel)) {
        $sql .= "nom_p = '" .  $nouveau_nom_personnel . "', ";
    }
    if (!empty($nouveau_prenom_personnel)) {
        $sql .= "prenom_p = '" . $nouveau_prenom_personnel . "', ";
    }
    if (!empty($nouvelle_date_naissance_manege)) {
        $sql .= "dn_p= " . $nouvelle_date_naissance_manege . ", ";
    }
    if (!empty($nouveau_ss_personnel)) {
        $sql .= "ss_p = " . $nouveau_ss_personnel . ", ";
    }
    if (!empty($nouveau_mdp_personnel)) {
        $sql .= "mdp_p = '" . $nouveau_mdp_personnel . "', ";
    }

    $sql = rtrim($sql, ", "); // Supprimer la dernière virgule
    $sql .= " WHERE id_p = " . $id_personnel;

    if (mysqli_query($conn, $sql)) {
        echo "Mise à jour effectuée avec succès.";
    } else {
        echo "Erreur: " . $sql . "<br>" . mysqli_error($conn);
    }
    if ($nouvelle_fonction_personnel != "rien") {
        if (!empty($nouvelle_fonction_personnel)) {
            $sql2 = "INSERT INTO $nouvelle_fonction_personnel (id_p) VALUES ('$id_personnel')";
            // Exécution de la requête SQL
            if ($conn->query($sql2) === TRUE) {
                echo "La fonction du personnel à été modifié avec succès.";
            } else {
                echo "Une erreur est survenue lors de la modification de la fonction du personnel : " . $conn->error;
            }
        }
    }
}


// Fermeture de la connexion à la base de données
mysqli_close($conn);

header('Location: directeur.php');
