<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$connexion = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// vérifier si l'ID du vendeur a été envoyé via POST
if (isset($_POST['id_v_s']) && isset($_POST['id_b_s'])) {
    $id_v = $_POST['id_v_s'];
    $id_b = $_POST['id_b_s'];

    // supprimer le vendeur correspondant de la table des vendeurs
    $sql = "DELETE FROM vend WHERE id_p = '$id_v' AND id_b='$id_b'";

    if (mysqli_query($conn, $sql)) {
        echo "Le vendeur a été supprimé avec succès.";
    } else {
        echo "Erreur lors de la suppression du vendeur : " . mysqli_error($conn);
    }
}

// fermer la connexion à la base de données
mysqli_close($conn);

// Redirection vers la page directeur
header('Location: directeur.php');