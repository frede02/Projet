<?php
$id = $_POST["id_man"];
$nom = $_POST["nom_man"];
$description = $_POST["description_man"];
$taille_min = $_POST["taille_min"];
$fonctionne = $_POST["fonctionne"];
$famille = $_POST["famille"];
$zone = $_POST["zone"];
$id_p = $_POST["id_perso"];

include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérifier si la connexion a réussi
if ($conn->connect_error) {
    die("La connexion a échoué : " . $conn->connect_error);
}

// Préparer la requête SQL pour insérer le manège
$sql = "INSERT INTO manege (id_m, nom_m, description_m, taille_min_m, fonctionne_m, nom_famille, id_p, nom_z) VALUES ('$id','$nom', '$description', '$taille_min', '$fonctionne', '$famille', '$id_p', '$zone')";

// Exécuter la requête SQL
if ($conn->query($sql) === TRUE) {
    echo "Le manège a été ajouté avec succès.";
} else {
    echo "Une erreur est survenue lors de l'ajout du manège : " . $conn->error;
}

// Fermer la connexion à la base de données
$conn->close();
// Redirection vers la page CM
header('Location: CM.html');
