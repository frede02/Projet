<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Récupération des données du formulaire
$id = $_POST["id_personnel"];
$nom = $_POST["nom_personnel"];
$prenom = $_POST["prenom_personnel"];
$date_naissance = $_POST["date_naissance"];
$ss = $_POST["ss"];
$mdp = $_POST["mdp"];
$fonction = $_POST["fonction"];

// Requête SQL pour insérer les données
$sql = "INSERT INTO Personnel (id_p, nom_p, prenom_p, db_p, ss_p, mdp_p) VALUES ('$id', '$nom', '$prenom', '$date_naissance', '$ss', '$mdp')";

// Exécution de la requête SQL
if ($conn->query($sql) === TRUE) {
    echo "Le personnel a été ajouté avec succès.";
} else {
    echo "Une erreur est survenue lors de l'ajout du personnel : " . $conn->error;
}
$sql2 = "INSERT INTO $fonction (id_p) VALUES ('$id')";

// Exécution de la requête SQL
if ($conn->query($sql2) === TRUE) {
    echo "Le personnel a été ajouté a sa fonction avec succès.";
} else {
    echo "Une erreur est survenue lors de l'ajout du personnel a sa fonction : " . $conn->error;
}

$conn->close();
// Redirection vers la page directeur
header('Location: directeur.html');
