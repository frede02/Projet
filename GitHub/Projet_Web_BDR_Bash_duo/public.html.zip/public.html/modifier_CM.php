<?php
include 'myparam.inc.php';
// Connexion à la base de données MySQL
$conn = mysqli_connect(HOST, USER, PASS, DB);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Vérification si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupération des données du formulaire
    $id_manege = $_POST["id_manege"];
    $nouveau_nom_manege = $_POST["nom_manege"];
    $nouvelle_description_manege = $_POST["description_manege"];
    $nouvelle_taille_min_manege = $_POST["taille_min_manege"];
    $nouvelle_fonctionne_manege = $_POST["fonctionne_manege"];
    $nouvelle_famille_manege = $_POST["nom_famille"];
    $nouvelle_zone_manege = $_POST["nom_zone"];

    // Requête SQL pour mettre à jour les données du manège
    $sql = "UPDATE manege SET ";
    if (!empty($nouveau_nom_manege)) {
        $sql .= "nom_m = '" . $nouveau_nom_manege . "', ";
    }
    if (!empty($nouvelle_description_manege)) {
        $sql .= "description_m = '" . $nouvelle_description_manege . "', ";
    }
    if (!empty($nouvelle_taille_min_manege)) {
        $sql .= "taille_min_m = " . $nouvelle_taille_min_manege . ", ";
    }
    
        $sql .= "fonctionne_m = " . $nouvelle_fonctionne_manege . ", ";
    
    if (!empty($nouvelle_famille_manege)) {
        $sql .= "nom_famille = '" . $nouvelle_famille_manege . "', ";
    }
    if (!empty($nouvelle_zone_manege)) {
        $sql .= "nom_z = '" . $nouvelle_zone_manege . "', ";
    }
    $sql = rtrim($sql, ", "); // Supprimer la dernière virgule
    $sql .= " WHERE id_m = " . $id_manege;

    if (mysqli_query($conn, $sql)) {
        echo "Mise à jour effectuée avec succès.";
    } else {
        echo "Erreur: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Fermeture de la connexion à la base de données
mysqli_close($conn);

header('Location: accueil_cm.php');