<?php
// se connecter à la base de données
$servername = "localhost"; // Nom de l'hôte
$username = "root"; // Nom d'utilisateur de la base de données
$password = "root"; // Mot de passe de la base de données
$dbname = "sae"; // Nom de la base de données
$conn = new mysqli("$servername", "$username", "$password", "$dbname");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Récupération des données du formulaire
$id_p = $_POST['id_v'];
$id_b = $_POST['id_b'];

$sql = "SELECT * FROM vendeur WHERE id_p='$id_p'";
if (!$sql) {
    echo "Le personnel selectionner n'est pas un vendeur : " . mysqli_error($conn);
    exit();
} else {
    // Construction de la requête SQL pour ajouter la boutique
    $sql1 = "INSERT INTO vend (id_p, id_b) VALUES ('$id_p', '$id_b')";

    // Exécution de la requête SQL
    if ($conn->query($sql1) === TRUE) {
        echo "La boutique a été ajouté avec succès.";
    } else {
        echo "Une erreur est survenue lors de l'ajout de la boutique : " . $conn->error;
    }
}

$conn->close();
// Redirection vers la page directeur
header('Location: directeur.php');
